import numpy as np


def write(filename, x, y):
    csv_file = open(filename, "w")
    csv_file.write('x, y\n')
    for x_i, y_i in zip(x, y):
        csv_file.write(f'{x_i}, {y_i}\n')
    csv_file.close()

    print("Обрати внимание на следующие точки:\nx, y")
    for x_i, y_i in zip(x, y):
        if np.isnan(y_i) or np.isinf(y_i) or np.isneginf(y_i) or np.isposinf(y_i):
            print(f"({x_i}, {y_i})")
