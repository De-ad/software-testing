import matplotlib.pyplot as plt
import numpy as np


def draw_plot(start, stop, x, y):

    plt.plot(x, y)
    plt.xlim(start, stop)
    ax = plt.gca()
    ax.axhline(y=0, color='k')
    ax.axvline(x=0, color='k')
    plt.show()
