import re
import numpy as np

replacements = {
    'sin(x)': 'np.sin(x)',
    'cos(x)': 'np.cos(x)',
    'tan(x)': 'np.tan(x)',
    'cot(x)': '(1/np.tan(x))',
    'sec(x)': '(1/np.cos(x))',
    'csc(x)': '(1/np.sin(x))',
    'log_2(x)': 'np.log2(x)',
    'log_3(x)': '(np.log(x)/np.log(3))',
    'log_5(x)': '(np.log(x)/np.log(5))',
    'log_10(x)': 'np.log10(x)',
    '^': '**',
}

allowed_words = [
    'sin(x)',
    'cos(x)',
    'tan(x)',
    'cot(x)',
    'sec(x)',
    'csc(x)',
    'log_2(x)',
    'log_3(x)',
    'log_5(x)',
    'log_10(x)',
]


def file2func(filename):
    text_file = open(filename, "r")
    string = text_file.read()
    text_file.close()

    string = string.replace(' ', '')

    words = set()

    trigonometrys = re.findall('[a-zA-Z]+\\(x\\)', string)
    logarithms = re.findall('log_[0-9]+\\(x\\)', string)

    for word in logarithms:
        words.add(word)
        if word not in allowed_words:
            raise ValueError(
                '"{}" -- вот этого нет среди логарифмов...'.format(word)
            )

    for word in trigonometrys:
        words.add(word)
        if word not in allowed_words:
            raise ValueError(
                '"{}" -- вот этого нет среди тригонометрии...'.format(word)
            )

    print(f'Обнаружил слова: {words}')

    for old, new in replacements.items():
        string = string.replace(old, new)

    def func(x):
        return eval(string)

    return func
