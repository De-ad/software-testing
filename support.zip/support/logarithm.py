import numpy as np

from util.artist import draw_plot
from util.converter import file2func
from util.writer import write

if __name__ == '__main__':

    ####################################################
    want_draw = True
    start = 0.1
    stop = 12
    step = 0.05
    ####################################################

    func = file2func('input/logarithm_base.txt')  # Вычисляем функцию по строчке
    assert stop > 0, 'Друг, не забывай, что по тз: x > 0'

    count = (stop - start) / step
    x = start + np.arange(0, count) * step  # Иксы
    y = func(x)  # Игреки

    write('output/logarithm_base_out.csv', x, y)
    draw_plot(start, stop, x, y) if want_draw else None  # Отрисовка графика
